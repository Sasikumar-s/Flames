from django.shortcuts import render
from django.http import HttpResponse

def home(request):
    return render(request, "home.html")
def back(request):
    return render(request,'home.html')

def result(request):
    fname = request.GET['uname'].lower()
    lname = request.GET['pname'].lower()
    fname_list_1 = list(fname)
    lname_list_1 = list(lname)

    fname = ""
    lname = ""

    if ' ' in fname_list_1:
        fname_list_1.remove(' ')


    if ' ' in lname_list_1:
        lname_list_1.remove(' ')

    fname_list = fname.join(fname_list_1)
    lname_list = lname.join(lname_list_1)

    if fname_list.isalpha() and lname_list.isalpha() :
        def test(v1,v2):
            for value in v1:
                if value !='':
                    if value in v2:
                        v1.remove(value)
                        v2.remove(value)
            return v1,v2
        i = 0
        while (i<=5) :
            v1,v2 = test(fname_list_1,lname_list_1)
            i+=1

        v=len(v1)+len(v2)
        j = 0
        l = ["FRIENDS","LOVE","AFFECTION","MARRIAGE","ENEMY","SISTER"]
        while len(l)>1:
            for i in range(v):
                j+=1
                if j >len(l):
                    j=1
            l.remove(l[j-1])
            j-=1

        if l[0] == 'FRIENDS':
            v = "True friends are always together in spirit. A true friend is someone who is there for you when he'd rather be anywhere else. A true friend is the greatest of all blessings, and that which we take the least care of all to acquire. A true friend is one who overlooks your failures and tolerates your success!" 
            return render(request, 'result.html', {'rest': l[0], 'val': v})
        elif l[0] == 'LOVE':
            v = "Staying in love and maintaining a relationship is a daily effort and doesn’t end at 'I love you.' Subtly reminding your partner that you are still in love with them signals that they are desired and that the chemistry between you two is thriving."
            return render(request,'result.html', {'rest': l[0], 'val': v})
        elif l[0] == 'AFFECTION':
            v = "Affection can mean anything from handholding to lovemaking. In fact, some men can most easily express their feelings during lovemaking. That's because after being intimate they feel as though they've loved you, and often feel loved as well."
            return render(request, 'result.html', {'rest': l[0], 'val': v})
        elif l[0] == 'MARRIAGE':
            v = "A marriage is just loving relation between two persons who lead normal life full of love,trust and sacrifice with special bond or knot made of one scarf"
            return render(request, 'result.html', {'rest': l[0], 'val': v})
        elif l[0] == 'ENEMY':
            v = "An enemy is a person who actively opposes someone or something. The Latin word inimicus, meaning \"hostile, unfriendly,\" is the root of enemy, and it comes \"from the prefix in-, or \"not,\" and amicus, friend: an enemy is \"not a friend. When two armies fight each other, they both think of the opposing army as the enemy."
            return render(request, 'result.html', {'rest': l[0], 'val': v})
        elif l[0] == 'SISTER':
            v = "Your friends will come and go, but you will always have your sister. And I promise that someday-she will be your best friend.\" On being there in the good times and the bad. \"You are the person who holds me in my bad times, you are the person who dances with me in my happiness"
            return render(request, 'result.html', {'rest': l[0], 'val': v})
        else:
             return HttpResponse('Go Back and refresh page and then enter the value correctly')
    else:
        return render(request, 'error.html',{'name':d})




