from django.apps import AppConfig


class FlmsConfig(AppConfig):
    name = 'flms'
